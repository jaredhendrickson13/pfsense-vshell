from setuptools import setup
setup(
    name='pfsense-vshell',
    author='Jared Hendrickson',
    author_email='jaredhendrickson13@gmail.com',
    packages=['pfvlib'],
    version='0.0.1_3',
    scripts=['pfsense-vshell'],
    install_requires=[
           "requests",
           "urllib3",
    ],
)